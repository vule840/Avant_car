=== Gravity Forms Google Places Addon ===
Contributors: davebonds
Author link: https://davebonds.com
Tags: gravity forms, google places, autocomplete, location
Requires at least: 3.5
Tested up to: 3.8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds a Gravity Forms field type for autocompleting addresses using the Google Places API.

== Description ==

This plugin is an addon for Gravity Forms that creates a new location field type to autocomplete addresses using Google Places API.

== Installation ==

1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Will this plugin support this or that? =

Eventually.


== Screenshots ==

1. 

== Changelog ==

= 1.0 =
* Initial release


== Roadmap ==

* Add support to Address field type to parse address and complete individual address field components.

